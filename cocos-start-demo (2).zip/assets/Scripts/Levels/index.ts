import Level1 from './level1'
import Level2 from './level2'

export const Levels = {
  Level1,
  Level2,
}
