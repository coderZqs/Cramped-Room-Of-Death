export enum EVENT_ENUM {
  NEXT_LEVEL = 'NEXT_LEVEL',
}
