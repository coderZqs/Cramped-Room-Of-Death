import { _decorator, Component, Node, UITransform, Sprite } from 'cc'
import Utils from '../Utils'
import { TileMapManager } from '../Tile/TileMapManager'
import { ILevel } from '../Enum/level'
import { Levels } from '../Levels'

import DataManager from '../Runtime/DataManager'

const { ccclass, property } = _decorator

@ccclass('BattleManager')
export class BattleManager extends Component {
  level: ILevel

  initLevel() {
    const level = Levels[`Level${1}`]
    this.level = level
  }

  generateTileMap() {
    const stage = Utils.createNode('stage')
    stage.setParent(this.node)

    const tileMap = Utils.createNode('tileMap')
    tileMap.setParent(stage)

    const tileMapManager = this.node.addComponent(TileMapManager)

    tileMapManager.init()
  }

  start() {
    this.generateTileMap()
  }
}
