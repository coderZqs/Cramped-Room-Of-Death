class SingleTon {
  private static instance: SingleTon
  static getInstance(): SingleTon {
    if (!SingleTon.instance) {
      SingleTon.instance = new SingleTon()
    }
    return SingleTon.instance
  }
}

export default SingleTon
