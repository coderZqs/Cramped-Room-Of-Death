import { _decorator, Component, Node } from 'cc'
import { Levels } from '../Levels/index'
import Utils from '../Utils/index'
import { TileManager } from './TileManager'

const { ccclass, property } = _decorator

@ccclass('TileMapManager')
export class TileMapManager extends Component {
  public stage: Node = null

  async init() {
    const spriteFrame = await Utils.loadRes('texture/tile/tile')

    const mapInfo = Levels.Level1.mapInfo
    for (let i = 0; i < mapInfo.length; i++) {
      const column = mapInfo[i]
      Levels.Level1.colCount = mapInfo.length

      for (let j = 0; j < column.length; j++) {
        const { src, type } = column[j]

        if (src === null || type === null) {
          continue
        }

        const node = Utils.createNode()
        const imgSrc = `tile (${src})`

        const index = spriteFrame.findIndex(e => e.name === imgSrc)
        const frame = spriteFrame[index]

        const tileManager = node.addComponent(TileManager)
        const tile = tileManager.init(frame, i, j)

        tile.setParent(this.node)
      }
    }
  }

  update(deltaTime: number) {}
}
