import { _decorator, Component, Node, UITransform, Sprite } from 'cc'
import Utils from '../Utils'

const { ccclass, property } = _decorator

@ccclass('TileManager')
export class TileManager extends Component {
  HEIGHT = 55
  WIDTH = 55

  init(spriteFrame, i, j) {
    const node = Utils.createNode()
    const uiTransform = node.getComponent(UITransform)
    uiTransform.setContentSize(this.WIDTH, this.HEIGHT)
    node.setPosition(i * this.WIDTH, -j * this.HEIGHT)
    const sprite = node.addComponent(Sprite)
    sprite.sizeMode = Sprite.SizeMode.CUSTOM
    sprite.spriteFrame = spriteFrame

    return node
  }
}
