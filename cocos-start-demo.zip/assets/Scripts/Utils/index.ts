import { resources, SpriteFrame, Node, UITransform, Vec2 } from 'cc'

const loadRes = (url: string): Promise<SpriteFrame[]> => {
  return new Promise((resolve, reject) => {
    resources.loadDir(url, SpriteFrame, (err, spriteFrames: SpriteFrame[]) => {
      if (err) {
        reject(err)
        return
      }

      resolve(spriteFrames)
    })
  })
}

const createNode = (name?: string) => {
  const node = new Node(name)
  const uiTransform = node.addComponent(UITransform)
  uiTransform.anchorPoint = new Vec2(0, 1)

  return node
}

export default {
  loadRes,
  createNode,
}
