import SingleTon from '../Base/SingleTon'
import { ILevel } from './../Enum/level'

class DataManager extends SingleTon {
  mapInfo: ILevel['mapInfo']
  mapRowCount: ILevel['rowCount']
  mapColCount: ILevel['colCount']
}

export default DataManager
