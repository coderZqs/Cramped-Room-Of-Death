import Level1 from './level1'

export const Levels = {
  Level1,
}
